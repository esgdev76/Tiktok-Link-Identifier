# TikTok Link Picker

A small Android app: a browser view of tiktok.com where you log in yourself, tap to
select several videos, and copy all their links to the clipboard in one go.

## Using the app

- **Select: OFF/ON** – turn on, then tap videos in a profile, search results,
  Favorites or Liked grid. Selected videos get a red outline and a check mark.
  Tap again to deselect.
- **+ This video** – while a single video page is open, adds that video's link.
- **Copy (n)** – copies all selected links, one per line.
- **Clear** – empties the selection.

Your login is stored by the in-app browser like a normal browser; the app never sees
your password.

## Getting the APK (no programming needed)

### Option A – GitHub (free, about 3 minutes)
1. Create a free account at github.com and make a new repository.
2. Upload every file of this folder (keep the folder structure, including `.github`).
3. Open the **Actions** tab -> **Build APK** -> **Run workflow**.
4. When it is green, open the run and download the artifact **TikTokLinkPicker-apk**.
   Unzip it to get `app-debug.apk` and install it on your phone
   (allow "Install unknown apps" for your browser/file manager when asked).

### Option B – Android Studio (PC)
Open this folder in Android Studio, let it sync, then
**Build -> Build Bundle(s)/APK(s) -> Build APK(s)**.
The file ends up in `app/build/outputs/apk/debug/app-debug.apk`.
