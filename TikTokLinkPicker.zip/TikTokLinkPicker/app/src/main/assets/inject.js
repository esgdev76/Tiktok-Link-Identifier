(function () {
  if (window.__ttInit) { return; }
  window.__ttInit = true;
  window.__ttSel = {};
  window.__ttMode = false;

  var RE = /^(https?:\/\/[^\/]*tiktok\.com\/@[^\/]+\/(?:video|photo)\/\d+)/;

  var style = document.createElement('style');
  style.textContent =
    'html.tt-mode a[href*="/video/"], html.tt-mode a[href*="/photo/"]{box-shadow:inset 0 0 0 2px rgba(254,44,85,.55);}' +
    'a[data-tt-sel="1"]{position:relative !important;outline:5px solid #fe2c55 !important;outline-offset:-5px;opacity:.65 !important;}' +
    'a[data-tt-sel="1"]::after{content:"\\2713";position:absolute;top:6px;right:6px;width:26px;height:26px;' +
    'line-height:26px;text-align:center;border-radius:50%;background:#fe2c55;color:#fff;' +
    'font:bold 16px sans-serif;z-index:99999;}';
  (document.head || document.documentElement).appendChild(style);

  function findLink(el) {
    while (el && el !== document) {
      if (el.tagName === 'A' && el.href) {
        var m = RE.exec(el.href);
        if (m) { return m[1]; }
      }
      el = el.parentNode;
    }
    return null;
  }

  function mark() {
    var as = document.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]');
    for (var i = 0; i < as.length; i++) {
      var m = RE.exec(as[i].href);
      if (m && window.__ttSel[m[1]]) {
        as[i].setAttribute('data-tt-sel', '1');
      } else {
        as[i].removeAttribute('data-tt-sel');
      }
    }
  }

  document.addEventListener('click', function (e) {
    if (!window.__ttMode) { return; }
    var url = findLink(e.target);
    if (!url) { return; }
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    TTBridge.toggle(url);
  }, true);

  window.__ttSet = function (list) {
    var s = {};
    for (var i = 0; i < list.length; i++) { s[list[i]] = 1; }
    window.__ttSel = s;
    mark();
  };

  window.__ttSetMode = function (on) {
    window.__ttMode = !!on;
    document.documentElement.classList.toggle('tt-mode', !!on);
  };

  var timer = null;
  new MutationObserver(function () {
    if (timer) { return; }
    timer = setTimeout(function () { timer = null; mark(); }, 400);
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
