package com.example.tiktoklinks;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String START_URL = "https://www.tiktok.com/";
    private static final Pattern VIDEO_URL =
            Pattern.compile("^https?://[^/]*tiktok\\.com/@[^/]+/(?:video|photo)/\\d+");

    private WebView web;
    private Button btnMode;
    private Button btnCopy;
    private boolean selectMode = false;
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();
    private String injectScript = "";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        injectScript = readAsset("inject.js");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#161823"));
        bar.setPadding(8, 8, 8, 8);
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        btnMode = makeButton(bar, "Select: OFF");
        Button btnAdd = makeButton(bar, "+ This video");
        btnCopy = makeButton(bar, "Copy (0)");
        Button btnClear = makeButton(bar, "Clear");

        btnMode.setOnClickListener(v -> {
            selectMode = !selectMode;
            refresh();
            if (selectMode) {
                Toast.makeText(this, "Tap videos to select them", Toast.LENGTH_SHORT).show();
            }
        });

        btnAdd.setOnClickListener(v -> {
            String url = normalize(web.getUrl());
            if (url == null) {
                Toast.makeText(this, "Open a single video first", Toast.LENGTH_SHORT).show();
                return;
            }
            if (selected.add(url)) {
                Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Already selected", Toast.LENGTH_SHORT).show();
            }
            refresh();
        });

        btnCopy.setOnClickListener(v -> {
            if (selected.isEmpty()) {
                Toast.makeText(this, "Nothing selected", Toast.LENGTH_SHORT).show();
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (String link : selected) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(link);
            }
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("TikTok links", sb.toString()));
            Toast.makeText(this, "Copied " + selected.size() + " link(s)", Toast.LENGTH_SHORT).show();
        });

        btnClear.setOnClickListener(v -> {
            selected.clear();
            refresh();
        });

        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // Look like regular mobile Chrome (WebView markers can make sites refuse login pages)
        String ua = s.getUserAgentString()
                .replace("; wv", "")
                .replaceAll("Version/\\d+\\.\\d+ ", "");
        s.setUserAgentString(ua);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "TTBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                // Block app deep links (tiktok://, intent://) so the page stays in the app
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                injectAll();
            }

            @Override
            public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                injectAll();
            }
        });

        if (savedInstanceState == null) {
            web.loadUrl(START_URL);
        } else {
            web.restoreState(savedInstanceState);
        }
        refresh();
    }

    private Button makeButton(LinearLayout bar, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(4, 0, 4, 0);
        bar.addView(b, lp);
        return b;
    }

    private void injectAll() {
        if (web == null) return;
        web.evaluateJavascript(injectScript, null);
        pushState();
    }

    private void pushState() {
        StringBuilder json = new StringBuilder("[");
        boolean first = true;
        for (String link : selected) {
            if (!first) json.append(',');
            first = false;
            json.append('"').append(link.replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        }
        json.append(']');
        web.evaluateJavascript(
                "if(window.__ttSetMode){window.__ttSetMode(" + selectMode + ");"
                        + "window.__ttSet(" + json + ");}", null);
    }

    private void refresh() {
        btnMode.setText(selectMode ? "Select: ON" : "Select: OFF");
        btnCopy.setText("Copy (" + selected.size() + ")");
        pushState();
    }

    private static String normalize(String url) {
        if (url == null) return null;
        Matcher m = VIDEO_URL.matcher(url);
        return m.find() ? m.group() : null;
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void toggle(String url) {
            final String u = normalize(url);
            if (u == null) return;
            runOnUiThread(() -> {
                if (!selected.remove(u)) {
                    selected.add(u);
                }
                refresh();
            });
        }
    }
}
